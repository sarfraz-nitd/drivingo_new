<?php

    $username="u589353249_coup";
    $password="fvLdy72Ryy";
    $database="u589353249_coup";

?>